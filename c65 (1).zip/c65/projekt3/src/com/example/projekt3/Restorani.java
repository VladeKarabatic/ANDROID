package com.example.projekt3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
/**
 * Created by 1 on 12/15/2014.
 */
public class Restorani extends MyActivity {
int odabirjezika;

    String[] text = { "1. take-away","2. malakavana","3. didovo zlato","4. velo misto","5. imperium"};

    int[] image = { R.drawable.takeaway,R.drawable.malakavanasplit2,R.drawable.didovozlato,R.drawable.velo_misto,R.drawable.imperium};

    ListItemDetails item_details;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle extras  = getIntent().getExtras();
        final Integer value  = extras.getInt("SOME_DATA" );
        odabirjezika=value;
        setContentView(R.layout.restorani_lokaliteti);

        ArrayList<ListItemDetails> result = GetSearchResults();
        final ListView lv = (ListView)findViewById(R.id.listView1);
        lv.setAdapter(new CustomListAdapter(result,getApplicationContext()));
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                switch( position )
                {
                    case 0:  Intent newActivity = new Intent(Restorani.this,Restorani_lokaliteti_opis.class);
                        newActivity.putExtra("SOME_DATA", position);
                        newActivity.putExtra("SOME_DATA2", odabirjezika);
                        startActivity(newActivity);
                        break;
                    case 1:
                        newActivity = new Intent(Restorani.this, Restorani_lokaliteti_opis.class);
                        newActivity.putExtra("SOME_DATA", position);
                        newActivity.putExtra("SOME_DATA2", odabirjezika);
                        startActivity(newActivity);
                        break;
                    case 2:
                        newActivity = new Intent(Restorani.this, Restorani_lokaliteti_opis.class);
                        newActivity.putExtra("SOME_DATA", position);
                        newActivity.putExtra("SOME_DATA2", odabirjezika);
                        startActivity(newActivity);
                        break;
                    case 3:
                        newActivity = new Intent(Restorani.this, Restorani_lokaliteti_opis.class);
                        newActivity.putExtra("SOME_DATA", position);
                        newActivity.putExtra("SOME_DATA2", odabirjezika);
                        startActivity(newActivity);
                        break;
                    case 4:
                        newActivity = new Intent(Restorani.this, Restorani_lokaliteti_opis.class);
                        newActivity.putExtra("SOME_DATA", position);
                        newActivity.putExtra("SOME_DATA2", odabirjezika);
                        startActivity(newActivity);
                        break;
                    case 5:
                        newActivity = new Intent(Restorani.this, Restorani_lokaliteti_opis.class);
                        newActivity.putExtra("SOME_DATA", position);
                        newActivity.putExtra("SOME_DATA2", odabirjezika);
                        startActivity(newActivity);
                        break;
                }


            }
        });


    }
    public ArrayList<ListItemDetails> GetSearchResults() {
        // TODO Auto-generated method stub
        ArrayList<ListItemDetails> results = new ArrayList<ListItemDetails>();

        for(int i=0;i<text.length;i++)
        {
            item_details= new ListItemDetails();
            item_details.setName(text[i]);
            item_details.setImage(image[i]);
            results.add(item_details);
        }

        return results;

    }
    @Override
    public void onBackPressed() {
        Intent myIntent = new Intent(Restorani.this,
                Izbornik.class);
        myIntent.putExtra("SOME_DATA", odabirjezika);
        startActivity(myIntent);
        // your code.
    }


}