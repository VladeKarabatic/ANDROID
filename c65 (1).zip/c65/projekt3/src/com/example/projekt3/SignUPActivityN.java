package com.example.projekt3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignUPActivityN extends MyActivity
{
    EditText editTextUserName,editTextPassword,editTextConfirmPassword;
    Button btnCreateAccount;
    int restoran1;
    int restoran2;
    int restoran3;
    int restoran4;
    int restoran5;
    int odabirjezika;

    LoginDataBaseAdapterN loginDataBaseAdapterN;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        Bundle extras  = getIntent().getExtras();
        final Integer value  = extras.getInt("SOME_DATA" );
        odabirjezika=value;
        if (odabirjezika==1){setContentView(R.layout.signup_nocni_klubovi_rezervacije_eng);}
        else {setContentView(R.layout.signup_nocni_klubovi_rezervacije);}
        // get Instance  of Database Adapter
        loginDataBaseAdapterN=new LoginDataBaseAdapterN(this);
        loginDataBaseAdapterN=loginDataBaseAdapterN.open();

        // Get Refferences of Views
        editTextUserName=(EditText)findViewById(R.id.editTextUserName);
        editTextPassword=(EditText)findViewById(R.id.editTextPassword);
        editTextConfirmPassword=(EditText)findViewById(R.id.editTextConfirmPassword);

        btnCreateAccount=(Button)findViewById(R.id.buttonCreateAccount);

        btnCreateAccount.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                // TODO Auto-generated method stub

                String userName=editTextUserName.getText().toString();
                String password=editTextPassword.getText().toString();
                String confirmPassword=editTextConfirmPassword.getText().toString();

                restoran1=Integer.valueOf(loginDataBaseAdapterN.getCount11());
                restoran2=Integer.valueOf(loginDataBaseAdapterN.getCount12());
                restoran3=Integer.valueOf(loginDataBaseAdapterN.getCount13());
                restoran4=Integer.valueOf(loginDataBaseAdapterN.getCount14());
                restoran5=Integer.valueOf(loginDataBaseAdapterN.getCount15());

                // check if any of the fields are vaccant
                if(userName.equals("")||password.equals("")||confirmPassword.equals(""))
                {
                    if (odabirjezika==1){Toast.makeText(getApplicationContext(), "Unesite sva polja", Toast.LENGTH_LONG).show();}
                    else {Toast.makeText(getApplicationContext(), "Please enter all fields", Toast.LENGTH_LONG).show();}
                    return;
                }
                // check if both password matches
                if(!password.equals(confirmPassword))
                {
                    Toast.makeText(getApplicationContext(), "Potvrdite ponovno", Toast.LENGTH_LONG).show();
                    return;
                }
                else
                {if (editTextUserName.getText().toString().equals("admin") &&
                        editTextPassword.getText().toString().equals("admin")) {
                    Toast.makeText(getApplicationContext(), "Hello admin!",
                            Toast.LENGTH_SHORT).show();
                    Intent myIntent = new Intent(SignUPActivityN.this,
                            AdministratorN.class);
                    myIntent.putExtra("SOME_DATA", odabirjezika);
                    startActivity(myIntent);

                } else if (String.valueOf(password).equals("1")){
                        if (restoran1>=5){

                            if (odabirjezika==1){Toast.makeText(getApplicationContext(), "Klub1 je popunjen", Toast.LENGTH_LONG).show();}
                            else{Toast.makeText(getApplicationContext(), "Klub1 is full", Toast.LENGTH_LONG).show();}

                        }else {
                            // Save the Data in Database
                            loginDataBaseAdapterN.insertEntry(userName, password);

                            if (odabirjezika==1){Toast.makeText(getApplicationContext(), "Uspješno ste rezervirali klub1", Toast.LENGTH_LONG).show();}
                            else {Toast.makeText(getApplicationContext(), "You have successfully made reservation", Toast.LENGTH_LONG).show();}
                        }






                } else if (String.valueOf(password).equals("2")){
                    if (restoran2>=5){


                        if (odabirjezika==1){ Toast.makeText(getApplicationContext(), "Klub2 je popunjen", Toast.LENGTH_LONG).show();}
                        else {Toast.makeText(getApplicationContext(), "Klub2 is full", Toast.LENGTH_LONG).show();}


                    }else {
                        // Save the Data in Database
                        loginDataBaseAdapterN.insertEntry(userName, password);


                        if (odabirjezika==1){Toast.makeText(getApplicationContext(), "Uspješno ste rezervirali klub2", Toast.LENGTH_LONG).show();}
                        else {Toast.makeText(getApplicationContext(), "You have successfully made reservation in Klub2", Toast.LENGTH_LONG).show();}
                    }






                } else if (String.valueOf(password).equals("3")){
                    if (restoran3>=5){

                        Toast.makeText(getApplicationContext(), "Klub3 je popunjen", Toast.LENGTH_LONG).show();


                    }else {
                        // Save the Data in Database
                        loginDataBaseAdapterN.insertEntry(userName, password);
                        Toast.makeText(getApplicationContext(), "Uspješno ste rezervirali Klub3", Toast.LENGTH_LONG).show();
                    }






                } else if (String.valueOf(password).equals("4")){
                    if (restoran4>=5){

                        Toast.makeText(getApplicationContext(), "Klub4 je popunjen", Toast.LENGTH_LONG).show();


                    }else {
                        // Save the Data in Database
                        loginDataBaseAdapterN.insertEntry(userName, password);
                        Toast.makeText(getApplicationContext(), "Uspješno ste rezervirali Klub4", Toast.LENGTH_LONG).show();
                    }






                } else if (String.valueOf(password).equals("5")){
                    if (restoran5>=5){

                        Toast.makeText(getApplicationContext(), "Klub5 je popunjen", Toast.LENGTH_LONG).show();


                    }else {
                        // Save the Data in Database
                        loginDataBaseAdapterN.insertEntry(userName, password);
                        Toast.makeText(getApplicationContext(), "Uspješno ste rezervirali Klub5", Toast.LENGTH_LONG).show();
                    }






                }else {
                    // Save the Data in Database

                    Toast.makeText(getApplicationContext(), "ZA KLUB1 UNESITE 1\nZA KLUB2 UNESITE 2\nZA KLUB3 UNESITE 3\nZA KLUB4 UNESITE 4\nZA KLUB5 UNESITE 5\n", Toast.LENGTH_LONG).show();
                }}
            }
        });
    }
    @Override
    public void onBackPressed() {
        Intent myIntent = new Intent(SignUPActivityN.this,
                Nocni_klubovi.class);
        myIntent.putExtra("SOME_DATA", odabirjezika);
        startActivity(myIntent);
        // your code.
    }
    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();

        loginDataBaseAdapterN.close();
    }
}
