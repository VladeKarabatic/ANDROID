package com.example.projekt3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by 1 on 12/16/2014.
 */
public class Administrator extends MyActivity{

    int brojac=0 ;
    int brkorisnika;
    int brkorisnika2;
    int odabirjezika;




    LoginDataBaseAdapter loginDataBaseAdapter;




    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        Bundle extras  = getIntent().getExtras();
        final Integer value  = extras.getInt("SOME_DATA" );
        odabirjezika=value;

        setContentView(R.layout.administrator);
        final TextView text1 = (TextView) findViewById(R.id.editTextUserName);
        final TextView text2 = (TextView) findViewById(R.id.editTextUserName2);

        Button btn1 = (Button)findViewById(R.id.buttonDelete);
        Button btn2 = (Button)findViewById(R.id.buttonDelete2);





        loginDataBaseAdapter=new LoginDataBaseAdapter(this);
        loginDataBaseAdapter=loginDataBaseAdapter.open();

        brkorisnika2=Integer.valueOf(loginDataBaseAdapter.getCount());


        if (brkorisnika==brkorisnika2){
            Intent myIntent = new Intent(Administrator.this,
                    SignUPActivity.class);
            myIntent.putExtra("SOME_DATA", odabirjezika);
            Toast.makeText(getApplicationContext(), "Došli ste do kraja baze", Toast.LENGTH_LONG).show();
            startActivity(myIntent);
        }else {
        text1.setText(loginDataBaseAdapter.getSinlgeEntry(brojac));
        text2.setText(loginDataBaseAdapter.getSinlgeEntry2(brojac));
            brkorisnika++;}


        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                brojac++;
                if (brkorisnika==brkorisnika2){
                    Intent myIntent = new Intent(Administrator.this,
                            SignUPActivity.class);
                    myIntent.putExtra("SOME_DATA", odabirjezika);
                    Toast.makeText(getApplicationContext(), "Došli ste do kraja baze", Toast.LENGTH_LONG).show();
                    startActivity(myIntent);
                }else {
                    text1.setText(loginDataBaseAdapter.getSinlgeEntry(brojac));
                    text2.setText(loginDataBaseAdapter.getSinlgeEntry2(brojac));
                    brkorisnika++;}


            }
        });


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                loginDataBaseAdapter.deleteEntry(loginDataBaseAdapter.getSinlgeEntry(brojac));
                Intent myIntent = new Intent(Administrator.this,
                        SignUPActivity.class);
                myIntent.putExtra("SOME_DATA", odabirjezika);
                Toast.makeText(getApplicationContext(), "Account deleted", Toast.LENGTH_LONG).show();
                startActivity(myIntent);
            }
        });

























            }




}
