package com.example.projekt3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by 1 on 12/16/2014.
 */
public class AdministratorO extends MyActivity{

    int brojac=0 ;
    int brkorisnika;
    int brkorisnika2;
    int odabirjezika;



    LoginDataBaseAdapterO loginDataBaseAdapterO;




    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        Bundle extras  = getIntent().getExtras();
        final Integer value  = extras.getInt("SOME_DATA" );
        odabirjezika=value;
        setContentView(R.layout.administrator2);

        final TextView text1 = (TextView) findViewById(R.id.editTextUserName1);
        final TextView text2 = (TextView) findViewById(R.id.editTextUserName2);
        final TextView text3 = (TextView) findViewById(R.id.editTextUserName3);
        final TextView text4 = (TextView) findViewById(R.id.editTextUserName4);

        Button btn1 = (Button)findViewById(R.id.buttonDelete);
        Button btn2 = (Button)findViewById(R.id.buttonDelete2);





        loginDataBaseAdapterO=new LoginDataBaseAdapterO(this);
        loginDataBaseAdapterO=loginDataBaseAdapterO.open();
        brkorisnika2=Integer.valueOf(loginDataBaseAdapterO.getCount());

        if (brkorisnika==brkorisnika2){
            Intent myIntent = new Intent(AdministratorO.this,
                    Ocjenjivanje.class);
            myIntent.putExtra("SOME_DATA", odabirjezika);
            Toast.makeText(getApplicationContext(), "Došli ste do kraja baze", Toast.LENGTH_LONG).show();
            startActivity(myIntent);
        }else {
            text1.setText(loginDataBaseAdapterO.getSinlgeEntry1(brojac));
            text2.setText(loginDataBaseAdapterO.getSinlgeEntry2(brojac));
            text3.setText(loginDataBaseAdapterO.getSinlgeEntry3(brojac));
            text4.setText(loginDataBaseAdapterO.getSinlgeEntry4(brojac));
            brkorisnika++;}




        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                brojac++;


                if (brkorisnika==brkorisnika2){
                    Intent myIntent = new Intent(AdministratorO.this,
                            Ocjenjivanje.class);
                    myIntent.putExtra("SOME_DATA", odabirjezika);
                    Toast.makeText(getApplicationContext(), "Došli ste do kraja baze", Toast.LENGTH_LONG).show();
                    startActivity(myIntent);
                }else {
                text1.setText(loginDataBaseAdapterO.getSinlgeEntry1(brojac));
                text2.setText(loginDataBaseAdapterO.getSinlgeEntry2(brojac));
                text3.setText(loginDataBaseAdapterO.getSinlgeEntry3(brojac));
                text4.setText(loginDataBaseAdapterO.getSinlgeEntry4(brojac));
                brkorisnika++;}


            }
        });


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                loginDataBaseAdapterO.deleteEntry(loginDataBaseAdapterO.getSinlgeEntry1(brojac));
                Intent myIntent = new Intent(AdministratorO.this,
                        Ocjenjivanje.class);
                myIntent.putExtra("SOME_DATA", odabirjezika);
                Toast.makeText(getApplicationContext(), "Account deleted", Toast.LENGTH_LONG).show();
                startActivity(myIntent);
            }
        });

























    }




}
