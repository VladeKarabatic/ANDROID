package com.example.projekt3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class LoginDataBaseAdapterO extends MyActivity {
    static final String DATABASE_NAME2 = "login.db7";
    static final int DATABASE_VERSION2 = 1;
    public static final int NAME_COLUMN = 1;
    // TODO: Create public field for each column in your table.
    // SQL Statement to create a new database.
    static final String DATABASE_CREATE2 = "create table "+"LOGIN"+
            "( " +"ID"+" integer primary key autoincrement,"+ "USERNAME  text,PASSWORD text,PASSWORD2 text,PASSWORD3 text); ";
    // Variable to hold the database instance
    public  SQLiteDatabase db2;
    // Context of the application using the database.
    private final Context context2;
    // Database open/upgrade helper
    private DataBaseHelperO dbHelper2;
    public LoginDataBaseAdapterO(Context _context)
    {
        context2 = _context;
        dbHelper2 = new DataBaseHelperO(context2, DATABASE_NAME2, null, DATABASE_VERSION2);
    }
    public LoginDataBaseAdapterO open() throws SQLException
    {
        db2 = dbHelper2.getWritableDatabase();
        return this;
    }
    public void close()
    {
        db2.close();
    }

    public  SQLiteDatabase getDatabaseInstance()
    {
        return db2;
    }

    public void insertEntry(String userName,String password,String password2,String password3)
    {
        ContentValues newValues = new ContentValues();
        // Assign values for each row.
        newValues.put("USERNAME", userName);
        newValues.put("PASSWORD",password);
        newValues.put("PASSWORD2",password2);
        newValues.put("PASSWORD3",password3);

        // Insert the row into your table
        db2.insert("LOGIN", null, newValues);
        ///Toast.makeText(context, "Reminder Is Successfully Saved", Toast.LENGTH_LONG).show();
    }
    public int deleteEntry(String UserName)
    {
        //String id=String.valueOf(ID);
        String where="USERNAME=?";
        int numberOFEntriesDeleted= db2.delete("LOGIN", where, new String[]{UserName}) ;
        // Toast.makeText(context, "Number fo Entry Deleted Successfully : "+numberOFEntriesDeleted, Toast.LENGTH_LONG).show();
        return numberOFEntriesDeleted;
    }
    public int deleteEntry(int i)
    {
        //String id=String.valueOf(ID);
        String where="USERNAME=?";
        int numberOFEntriesDeleted= db2.delete("LOGIN", where, new String[i]) ;
        // Toast.makeText(context, "Number fo Entry Deleted Successfully : "+numberOFEntriesDeleted, Toast.LENGTH_LONG).show();
        return numberOFEntriesDeleted;
    }
    public String getSinlgeEntry(String userName)
    {
        Cursor cursor=db2.query("LOGIN", null, " USERNAME=?", new String[]{userName}, null, null, null);
        if(cursor.getCount()<1) // UserName Not Exist
        {
            cursor.close();
            return "NOT EXIST";
        }
        cursor.moveToFirst();
        String password= cursor.getString(cursor.getColumnIndex("PASSWORD"));
        cursor.close();
        return password;
    }
    public String getSinlgeEntry1(int i)
    {
        Cursor cursor = db2.query("LOGIN",null, null, null, null, null, null);
        cursor.moveToPosition(i);
        String username= cursor.getString(cursor.getColumnIndex("USERNAME"));
        cursor.close();
        return username;
    }
    public String getSinlgeEntry2(int i)
    {
        Cursor cursor = db2.query("LOGIN",null, null, null, null, null, null);
        cursor.moveToPosition(i);
        String password= cursor.getString(cursor.getColumnIndex("PASSWORD"));
        cursor.close();
        return password;
    }
    public String getSinlgeEntry3(int i)
    {
        Cursor cursor = db2.query("LOGIN",null, null, null, null, null, null);
        cursor.moveToPosition(i);
        String password2= cursor.getString(cursor.getColumnIndex("PASSWORD2"));
        cursor.close();
        return password2;
    }
    public String getSinlgeEntry4(int i)
    {
        Cursor cursor = db2.query("LOGIN",null, null, null, null, null, null);
        cursor.moveToPosition(i);
        String password3= cursor.getString(cursor.getColumnIndex("PASSWORD3"));
        cursor.close();
        return password3;
    }
    public String getCount()
    {
        Cursor cursor = db2.query("LOGIN", null, null, null, null, null, null);

        int count = cursor.getCount();

        return String.valueOf(count);

    }
    public String getSinlgeEntry1()
    {

        Cursor cursor = db2.query("LOGIN", null, null, null, null, null, null);
        int count = cursor.getCount();

        cursor.moveToPosition(0);
        while (count>0) {
            String password = cursor.getString(cursor.getColumnIndex("USERNAME"));
            cursor.close();
            count--;
            return password;
        }

        return null;

    }

    public void  updateEntry(String userName,String password)
    {
        // Define the updated row content.
        ContentValues updatedValues = new ContentValues();
        // Assign values for each row.
        updatedValues.put("USERNAME", userName);
        updatedValues.put("PASSWORD",password);

        String where="USERNAME = ?";
        db2.update("LOGIN",updatedValues, where, new String[]{userName});
    }



}
