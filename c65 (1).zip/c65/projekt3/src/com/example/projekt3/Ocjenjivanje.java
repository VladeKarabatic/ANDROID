package com.example.projekt3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by 1 on 12/23/2014.
 */
public class Ocjenjivanje extends MyActivity{
    EditText editTextUserName,editTextPassword,editTextConfirmPassword,editTextConfirmPassword2;
    Button btnCreateAccount;
    int odabirjezika;

    LoginDataBaseAdapterO loginDataBaseAdapterO;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        Bundle extras  = getIntent().getExtras();
        final Integer value  = extras.getInt("SOME_DATA" );
        odabirjezika=value;
        if (odabirjezika==1){ setContentView(R.layout.signup2_eng);}
        else{ setContentView(R.layout.signup2);}


        // get Instance  of Database Adapter
        loginDataBaseAdapterO=new LoginDataBaseAdapterO(this);
        loginDataBaseAdapterO=loginDataBaseAdapterO.open();

        // Get Refferences of Views
        editTextUserName=(EditText)findViewById(R.id.editTextUserName);
        editTextPassword=(EditText)findViewById(R.id.editTextPassword);
        editTextConfirmPassword=(EditText)findViewById(R.id.editTextConfirmPassword);
        editTextConfirmPassword2=(EditText)findViewById(R.id.editTextConfirmPassword2);

        btnCreateAccount=(Button)findViewById(R.id.buttonCreateAccount);
        btnCreateAccount.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                // TODO Auto-generated method stub

                String userName=editTextUserName.getText().toString();
                String password=editTextPassword.getText().toString();
                String password2=editTextConfirmPassword.getText().toString();
                String password3=editTextConfirmPassword2.getText().toString();


                // check if any of the fields are vaccant
               if (editTextUserName.getText().toString().equals("admin")) {
                    Toast.makeText(getApplicationContext(), "Hello admin!",
                            Toast.LENGTH_SHORT).show();
                    Intent myIntent = new Intent(Ocjenjivanje.this,
                            AdministratorO.class);
                   myIntent.putExtra("SOME_DATA", odabirjezika);
                    startActivity(myIntent);

                } else {
                    // Save the Data in Database
                    loginDataBaseAdapterO.insertEntry(userName, password, password2, password3);
                    Toast.makeText(getApplicationContext(), "Account Successfully Created ", Toast.LENGTH_LONG).show();
                }}

        });
    }
    @Override
    public void onBackPressed() {
        Intent myIntent = new Intent(Ocjenjivanje.this,
                Izbornik.class);
        myIntent.putExtra("SOME_DATA", odabirjezika);
        startActivity(myIntent);
        // your code.
    }
    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();

        loginDataBaseAdapterO.close();
    }
}
