package com.example.projekt3;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by 4 on 12/12/2014.
 */
public class Povijesni_lokaliteti_opis extends MyActivity {

int odabirjezika;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.povijesni_lokaliteti_opis);


        Bundle extras  = getIntent().getExtras();
        if  (extras  != null)  {
            final Integer value  = extras.getInt("SOME_DATA" );
            final Integer value2  = extras.getInt("SOME_DATA2" );
            odabirjezika=value2;


            Button btn1 = (Button)findViewById(R.id.button2);
            Button btn2 = (Button)findViewById(R.id.button3);
        final TextView textElement = (TextView) findViewById(R.id.textView);
        final String newText;
        newText = "Gradski stadion u Poljudu, poznat pod nadimkom Poljudska ljepotica, nalazi se u splitskoj četvrti Poljudu na sjeverozapadu grada, na mjestu gdje je nekad bilo ljekovito blato. Izgrađen je 1979. godine u sklopu izgradnje športskih objekata 8. Mediteranskih igara.Autor projekta je istaknuti riječki arhitekt dr. Boris Magaš. Stadion je utjecao na arhitektonske vizure brojnih svjetskih stadiona u Italiji, Japanu (Kobe) i Maleziji. Nakon münchenskog Olimpijskog stadiona, izazvao je najviše pozornosti stručne javnosti na polju športske arhitekture.";
            final String newText2 = "Dioklecijanova palača je antička palača cara Dioklecijana u Splitu.Oko 300. godine podigao ju je rimski car Dioklecijan i u njoj boravio nakon povlačenja s prijestolja (305.) do smrti (316.).Sagrađena je u uvali poluotoka 5 km jugozapadno od Salone, glavnoga grada provincije Dalmacije. Ostatci palače danas su dio povijesne jezgre Splita koja je upisana na UNESCO-v popis mjesta svjetske baštine u Europi još 1979. godine.";
            switch( value )
            {case 0:  textElement.setText(newText);break;
                case 1:  textElement.setText(newText2);break;}




            btn1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    switch( value )
                {case 0: {Uri uri = Uri.parse("http://www.hajduk.hr/klub/stadion");
                    startActivity(new Intent(Intent.ACTION_VIEW, uri)); break;}
                    case 1: {
                        Uri uri = Uri.parse("http://www.splitculture.hr/dozivljaj/povijest/dioklecijanova-palaca");
                        startActivity(new Intent(Intent.ACTION_VIEW, uri)); break;}}

                }
            });
            btn2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    switch( value ){


                        case 0:{Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(Uri.parse("geo:43.519613846118624,16.432172656059265?z=18"));
                            Intent chooser = Intent.createChooser(intent, "Launch Maps");
                            startActivity(chooser);break;}
                        case 1:{Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(Uri.parse("geo:43.50876682037105,16.440448546827554?z=18"));
                            Intent chooser = Intent.createChooser(intent, "Launch Maps");
                            startActivity(chooser);break;}



                    }

                }
            });



        }
    }@Override
     public void onBackPressed() {
        Intent myIntent = new Intent(Povijesni_lokaliteti_opis.this,
                Povijesni_lokaliteti.class);
        myIntent.putExtra("SOME_DATA", odabirjezika);
        startActivity(myIntent);
        // your code.
    }}
