package com.example.projekt3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class LoginDataBaseAdapterN extends MyActivity {
    static final String DATABASE_NAME3 = "KLUBOVI";
    static final int DATABASE_VERSION = 1;
    public static final int NAME_COLUMN = 1;
    // TODO: Create public field for each column in your table.
    // SQL Statement to create a new database.
    static final String DATABASE_CREATE3 = "create table "+"LOGIN"+
            "( " +"ID"+" integer primary key autoincrement,"+ "USERNAME  text,PASSWORD text); ";
    // Variable to hold the database instance
    public  SQLiteDatabase db3;
    // Context of the application using the database.
    private final Context context3;
    // Database open/upgrade helper
    private DataBaseHelperN dbHelper3;
    public LoginDataBaseAdapterN(Context _context)
    {
        context3 = _context;
        dbHelper3 = new DataBaseHelperN(context3, DATABASE_NAME3, null, DATABASE_VERSION);
    }
    public LoginDataBaseAdapterN open() throws SQLException
    {
        db3 = dbHelper3.getWritableDatabase();
        return this;
    }
    public void close()
    {
        db3.close();
    }

    public  SQLiteDatabase getDatabaseInstance()
    {
        return db3;
    }

    public void insertEntry(String userName,String password)
    {
        ContentValues newValues = new ContentValues();
        // Assign values for each row.
        newValues.put("USERNAME", userName);
        newValues.put("PASSWORD",password);

        // Insert the row into your table
        db3.insert("LOGIN", null, newValues);
        ///Toast.makeText(context, "Reminder Is Successfully Saved", Toast.LENGTH_LONG).show();
    }
    public int deleteEntry(String UserName)
    {
        //String id=String.valueOf(ID);
        String where="USERNAME=?";
        int numberOFEntriesDeleted= db3.delete("LOGIN", where, new String[]{UserName}) ;
        // Toast.makeText(context, "Number fo Entry Deleted Successfully : "+numberOFEntriesDeleted, Toast.LENGTH_LONG).show();
        return numberOFEntriesDeleted;
    }
    public int deleteEntry(int i)
    {
        //String id=String.valueOf(ID);
        String where="USERNAME=?";
        int numberOFEntriesDeleted= db3.delete("LOGIN", where, new String[i]) ;
        // Toast.makeText(context, "Number fo Entry Deleted Successfully : "+numberOFEntriesDeleted, Toast.LENGTH_LONG).show();
        return numberOFEntriesDeleted;
    }
    public String getSinlgeEntry(String userName)
    {
        Cursor cursor=db3.query("LOGIN", null, " USERNAME=?", new String[]{userName}, null, null, null);
        if(cursor.getCount()<1) // UserName Not Exist
        {
            cursor.close();
            return "NOT EXIST";
        }
        cursor.moveToFirst();
        String password= cursor.getString(cursor.getColumnIndex("PASSWORD"));
        cursor.close();
        return password;
    }
    public String getSinlgeEntry(int i)
    {
        Cursor cursor = db3.query("LOGIN",null, null, null, null, null, null);
        cursor.moveToPosition(i);
        String password= cursor.getString(cursor.getColumnIndex("USERNAME"));
        cursor.close();
        return password;
    }
    public String getSinlgeEntry2(int i)
    {
        Cursor cursor = db3.query("LOGIN",null, null, null, null, null, null);
        cursor.moveToPosition(i);
        String password2= cursor.getString(cursor.getColumnIndex("PASSWORD"));
        cursor.close();
        return password2;
    }
    public int getCount1()
    {
        Cursor cursor = db3.query("LOGIN", null, null, null, null, null, null);

        int count = cursor.getCount();

        return count;
    }
    public String getCount()
    {
        Cursor cursor = db3.query("LOGIN", null, null, null, null, null, null);

        int count = cursor.getCount();

        return String.valueOf(count);

    }
    public String getCount11()
    {int count11 = 0;
        String count21;

        Cursor cursor = db3.query("LOGIN", null, null, null, null, null, null);
        int count = cursor.getCount();
        for(int i=0;i<count;i++){
            cursor.moveToPosition(i);
            String password2= cursor.getString(cursor.getColumnIndex("PASSWORD"));
            if (String.valueOf(password2).equals("1")){
                count11++;
            }



        }
        count21=String.valueOf(count11);

        return count21;

    }
    public String getCount12()
    {int count11 = 0;
        String count21;

        Cursor cursor = db3.query("LOGIN", null, null, null, null, null, null);
        int count = cursor.getCount();
        for(int i=0;i<count;i++){
            cursor.moveToPosition(i);
            String password2= cursor.getString(cursor.getColumnIndex("PASSWORD"));
            if (String.valueOf(password2).equals("2")){
                count11++;
            }



        }
        count21=String.valueOf(count11);

        return count21;

    }public String getCount13()
    {int count11 = 0;
        String count21;

        Cursor cursor = db3.query("LOGIN", null, null, null, null, null, null);
        int count = cursor.getCount();
        for(int i=0;i<count;i++){
            cursor.moveToPosition(i);
            String password2= cursor.getString(cursor.getColumnIndex("PASSWORD"));
            if (String.valueOf(password2).equals("3")){
                count11++;
            }



        }
        count21=String.valueOf(count11);

        return count21;

    }public String getCount14()
    {int count11 = 0;
        String count21;

        Cursor cursor = db3.query("LOGIN", null, null, null, null, null, null);
        int count = cursor.getCount();
        for(int i=0;i<count;i++){
            cursor.moveToPosition(i);
            String password2= cursor.getString(cursor.getColumnIndex("PASSWORD"));
            if (String.valueOf(password2).equals("4")){
                count11++;
            }



        }
        count21=String.valueOf(count11);

        return count21;

    }public String getCount15()
    {int count11 = 0;
        String count21;

        Cursor cursor = db3.query("LOGIN", null, null, null, null, null, null);
        int count = cursor.getCount();
        for(int i=0;i<count;i++){
            cursor.moveToPosition(i);
            String password2= cursor.getString(cursor.getColumnIndex("PASSWORD"));
            if (String.valueOf(password2).equals("5")){
                count11++;
            }



        }
        count21=String.valueOf(count11);

        return count21;

    }
    public String getSinlgeEntry1()
    {

        Cursor cursor = db3.query("LOGIN", null, null, null, null, null, null);
        int count = cursor.getCount();

        cursor.moveToPosition(0);
        while (count>0) {
            String password = cursor.getString(cursor.getColumnIndex("USERNAME"));
            cursor.close();
            count--;
            return password;
        }

        return null;

    }

    public void  updateEntry(String userName,String password)
    {
        // Define the updated row content.
        ContentValues updatedValues = new ContentValues();
        // Assign values for each row.
        updatedValues.put("USERNAME", userName);
        updatedValues.put("PASSWORD",password);

        String where="USERNAME = ?";
        db3.update("LOGIN",updatedValues, where, new String[]{userName});
    }



}
