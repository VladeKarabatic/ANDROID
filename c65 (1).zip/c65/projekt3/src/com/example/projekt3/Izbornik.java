package com.example.projekt3;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * Created by 4 on 1/6/2015.
 */
public class Izbornik extends Activity {


int odabirjezika;



/** Called when the activity is first created. */
@Override
public void onCreate(Bundle savedInstanceState)
        {
        super.onCreate(savedInstanceState);
            Bundle extras  = getIntent().getExtras();
            final Integer value  = extras.getInt("SOME_DATA" );
            odabirjezika=value;

            if (odabirjezika==1) {setContentView(R.layout.main_eng);
            } else {
                setContentView(R.layout.main);}

            Button btn1 = (Button)findViewById(R.id.button);
        Button btn2 = (Button)findViewById(R.id.button2);
        Button btn4 = (Button)findViewById(R.id.button4);
        Button btn5= (Button)findViewById(R.id.button5);

        btn1.setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View v) {
        Intent myIntent = new Intent(Izbornik.this,
        Povijesni_lokaliteti.class);
    myIntent.putExtra("SOME_DATA", odabirjezika);
        startActivity(myIntent);
        }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View v) {
        Intent myIntent = new Intent(Izbornik.this,
        Restorani.class);
    myIntent.putExtra("SOME_DATA", odabirjezika);
        startActivity(myIntent);
        }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View view) {
        Intent myIntent = new Intent(Izbornik.this,
        Ocjenjivanje.class);
    myIntent.putExtra("SOME_DATA", odabirjezika);
        startActivity(myIntent);
        }
        });
        btn5.setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View view) {
        Intent myIntent = new Intent(Izbornik.this,
        Nocni_klubovi.class);
    myIntent.putExtra("SOME_DATA", odabirjezika);
        startActivity(myIntent);
        }
        });



        }
    @Override
    public void onBackPressed() {
        Intent myIntent = new Intent(Izbornik.this,
                MyActivity.class);
        startActivity(myIntent);
        // your code.
    }
        }
