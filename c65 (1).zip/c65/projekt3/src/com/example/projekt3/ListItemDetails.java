package com.example.projekt3;

/**
 * Created by 4 on 12/12/2014.
 */
public class ListItemDetails {

    private String name;
    private int image;

    public String getName()
    {
        return name;
    }
    public void setName(String name)
    {
        this.name = name;
    }
    public int getImage()
    {
        return image;
    }
    public void setImage(int image)
    {
        this.image = image;
    }
}
