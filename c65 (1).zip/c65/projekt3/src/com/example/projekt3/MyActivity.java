package com.example.projekt3;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MyActivity extends Activity
{
    public int odabirjezika;






    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.language);

Button btn1 = (Button)findViewById(R.id.button);
    Button btn2 = (Button)findViewById(R.id.button2);


btn1.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        odabirjezika=0;

        Intent myIntent = new Intent(MyActivity.this,
                Izbornik.class);
       myIntent.putExtra("SOME_DATA", odabirjezika);
        startActivity(myIntent);
    }
});

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odabirjezika=1;

                Intent myIntent = new Intent(MyActivity.this,
                        Izbornik.class);
                myIntent.putExtra("SOME_DATA", odabirjezika);
                startActivity(myIntent);
            }
        });



        }
}
